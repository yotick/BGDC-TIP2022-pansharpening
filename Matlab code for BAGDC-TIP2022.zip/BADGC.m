function F = BADGC(img_mul, M, P)
global  sensor ratio  sate;
% img_mul is an MS image at orginal size, but normalized to 0-1
% M is the up sampled version of img_mul
% P is a PAN image normalzied to 0-1
%% processing %%
[m,~] = size(P);
[~,~,b] = size(img_mul);
[I,~] = get_I(sate,M, P);


H_M = get_H_MTF_M(M,sensor,[],ratio);
%     H_P = get_H_MTF_P(P,sensor,ratio);

Pd = imresize(P,1/4, 'bicubic');

%% original
M_sum = zeros(size(M,1),size(M,2));
for i = 1:size(M,3)
    M_sum = M_sum + M(:,:,i);
end
M_sum(find(M_sum==0))=eps;

M_rate = zeros(size(M));
for i=1:size(M,3)
    M_rate(:,:,i) = size(M,3)*M(:,:,i)./M_sum;
end

g1 = ones(1,size(M,3));
for ii = 1 : size(M,3)
    h = M(:,:,ii);
    c = cov(I(:),h(:));
    g1(1, ii) = c(1,2)/var(I(:));
end
%% switch

switch sate
    case 'ik'
        g = 0.82;
        u_grad = 0.15;
        lamda = 0.45;
        gama_lagr = 0.009;        
    case 'pl'
        g = 0.79;
        u_grad = 0.5;
        lamda = 1.5;
        gama_lagr = 0.025;

    case {'wv3','wv3-8'}        
        g= 1.35;
        u_grad = 0.09;   % for wv3-8
        lamda = 0.3;        
        gama_lagr = 1.2e-4;
        
    case {'tg'}
        g =3.5;
        u_grad = 0.09;
        lamda = 0.35;
        gama_lagr = 1.2e-4;
end

%%% Coefficients

%% ************ function *******
a = get_co_grad(Pd, img_mul);

[D,k1] = get_D_red(P,img_mul);
k = k1;

lap = fspecial('laplacian',0);
lap_f = freqz2(lap,size(P)); % laplase matrix
lap_f = fftshift(lap_f);

P_f = fft2(P);
%     PL_f = fft2(P_L);

eps = 1*10^-3;
iter = 0;
lagr_m = ones(m);                % lagrange factor
u_aug = 0.2;             % augment lagrange parameter
X = 0;
%     gama_lagr = 0.00001;
rho = 1.01;

for i=1:b
    %          k(i) = 1;
    M_f = fft2(M(:,:,i));
    H_f = H_M(:,:,i);
    D_f = fft2(D(:,:,i));
    
    M_hr_old(:,:,i) = I;
    M_hr_new(:,:,i) = P;
    N_I = norm(M_hr_new(:,:,i)-M_hr_old(:,:,i))/norm(M_hr_old(:,:,i));
    while (N_I>eps)
        M_hr_old(:,:,i) = M_hr_new(:,:,i);
        iter = iter + 1;
        A = H_f'.*M_f + u_grad*a(i)*lap_f'.*lap_f'.* P_f + lamda* (M_f + k(i)*D_f) + lap_f.*fft2(lagr_m) + u_aug*lap_f.*fft2(X);
        B = H_f'.*H_f' + u_grad * a(i)^2*lap_f'.*lap_f' + lamda + u_aug*lap_f'.*lap_f';
        C = A./B;
        M_hr_new(:,:,i) = real(ifft2(C));
        
        X = shrink(real(ifft2(lap_f.*C))-1/u_aug*lagr_m, gama_lagr/u_aug);
        lagr_m = lagr_m +u_aug*(X - real(ifft2(lap_f.*C)));
        u_aug = rho*u_aug;
        N_I =  norm(M_hr_new(:,:,i)-M_hr_old(:,:,i))/norm(M_hr_old(:,:,i));
        %         F_final(:,:,i) = M(:,:,i)+ M_rate(:,:,i).*(M_hr(:,:,i)-M(:,:,i));
    end
    F_final(:,:,i) = M(:,:,i)+ g*M_rate(:,:,i).* (M_hr_new(:,:,i)-M(:,:,i));   
    F = F_final;
    
end