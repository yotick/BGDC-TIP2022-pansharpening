clc; clear all; close all;
% since the full scale image is too large, use block process anyway.

global  sensor ratio  sate;
curr_d = pwd;
sate = 'ik';   % ik,pl��wv3-8
sensor = 'IKONOS';
ratio = 4;
method = 'BAGDC';
%% start initialization
% initialize_sate_FS();


%% read images and preprocess, need to change
[mul_noR, pan_noR ] = read_image_sate_FS(num);
% mul_noR is full scale MS image
% pan_noR is full scale PAN image
%% tic start
tic()
%     ORM = gt256;
img_mul = im2double(mul_noR);
P = im2double(pan_noR);

%% start processing 
[m,n] = size(P);
M =imresize(img_mul,size(P),'bicubic');   % ˫���β�ֵ�㷨
img_mul_U = imresize(img_mul,size(P),'nearest'); % temp
img_mul_L = MTF(img_mul,sensor,0,ratio);


%% original
M_sum = M(:,:,1)+M(:,:,2)+M(:,:,3)+M(:,:,4);
M_sum(find(M_sum==0))=eps;
M_rate = zeros(size(M));
for i=1:4
    M_rate(:,:,i) = 4*M(:,:,i)./M_sum;
end

%% block processing
S_block = 256;

in3 = cat(3,M,img_mul_U, P);
fun_inj = @(bs)BADGC_F(bs.data);
%     De = blockproc(in3,[S_block, S_block],fun_crf,'BorderSize',[2,2]);
M_hr_new = blockproc(in3,[S_block, S_block],fun_inj,'BorderSize',[4,4]);

F_final = zeros(size(M));
for i = 1:4
    F_final(:,:,i) = M(:,:,i)+ g*M_rate(:,:,i).* (M_hr_new(:,:,i)-M(:,:,i));
end
%% end and get RGB
toc
time(num) = toc;

for i = 1:3
    F_rgb(:,:,i) =  F_final(:,:,i);
    
    %         F_rgb2(:,:,i) =  F_final2(:,:,i);
end
%% ##### save images, should be changed #######
save_sate_FS(F_final, M, F_rgb, num);

%     F_rgb(:,:,1) =  F_final(:,:,3);
%     F_rgb(:,:,2) =  F_final(:,:,2);
%     F_rgb(:,:,3) =  F_final(:,:,1);
%% show image
figure, imshow(F_rgb);
[Dl,Ds,QNR_index,SAM_index,sCC] = indexes_evaluation_FS(F_final,img_mul,P,...
    L,thvalues,M,sensor,im_tag,ratio);
% [D_lambda,D_S,QNR_index,SAM_index,sCC] = indexes_evaluation_FS(Fused,I_MS_LR,I_PAN);
Eval = [Dl,Ds,QNR_index,SAM_index,sCC]
cd(curr_d);
%% write result
T = quality_eval_sate_FS();
cd(curr_d);
writetable(T,strcat('final_result/quality_',method,'_4C_',sate,'_FS_b2.csv'),'WriteRowNames',true);

%% ************function start here**************
function M_hr_new = BADGC_F(in3)
global  sensor ratio  sate ;

M = in3(:,:,1:4);
img_mul_U = in3(:,:,5:8);
P = in3(:,:,9);
[m,~] = size(P);
img_mul = imresize(img_mul_U,1/4, 'nearest');
[I,~] = get_I(sate,M, P);
H_M = get_H_MTF_M(M,sensor,[],ratio);
%% switch
switch sate
    case 'ik'
        %             k = 1.1;
        g = 0.82;

        u_grad = 0.15;
        lamda = 0.35;
        gama_lagr = 0.009;
    case 'pl'
        g = 0.79;
        u_grad = 0.5;
        lamda = 2.5;
        gama_lagr = 0.015;
    case 'wv2'
        %             k = 1.5;
        g = 1.2;
    case 'wv3'
        %             k = 1.5;
        g = 1.25;
        u_grad = 0.04;
        lamda = 0.35;
        gama_lagr = 1.2e-4;
        %              g = 1.23;
    case 'qb'
        g = 0.80;
    case 'geo'
        g = 0.95;
end
%%  start
Pd = imresize(P,1/4, 'bicubic');
a = get_co_grad(Pd, img_mul);
%     a = [1,1,1,1];
%     beta = get_co_De(P, img_mul);
[D,k1] = get_D_red(P,img_mul);
k = k1;

lap = fspecial('laplacian',0);
lap_f = freqz2(lap,size(P)); % laplase matrix
lap_f = fftshift(lap_f);

P_f = fft2(P);
%     PL_f = fft2(P_L);

eps = 2*10^-3;
iter = 0;
lagr_m = ones(m);                % lagrange factor
u_aug = 0.2;             % augment lagrange parameter
X = 0;
%     gama_lagr = 0.00001;
rho = 1.01;

for i=1:4
    %          k(i) = 1;
    M_f = fft2(M(:,:,i));
    H_f = H_M(:,:,i);
    D_f = fft2(D(:,:,i));
    
    M_hr_old(:,:,i) = I;
    M_hr_new(:,:,i) = P;
    N_I = norm(M_hr_new(:,:,i)-M_hr_old(:,:,i))/norm(M_hr_old(:,:,i));
    while (N_I>eps)
        M_hr_old(:,:,i) = M_hr_new(:,:,i);
        %         iter = iter + 1
        A = H_f'.*M_f + u_grad*a(i)*lap_f'.*lap_f'.* P_f + lamda* (M_f + k(i)*D_f) + lap_f.*fft2(lagr_m) + u_aug*lap_f.*fft2(X);
        B = H_f'.*H_f' + u_grad * a(i)^2*lap_f'.*lap_f' + lamda + u_aug*lap_f'.*lap_f';
        C = A./B;
        M_hr_new(:,:,i) = real(ifft2(C));
        
        X = shrink(real(ifft2(lap_f.*C))-1/u_aug*lagr_m, gama_lagr/u_aug);
        lagr_m = lagr_m +u_aug*(X - real(ifft2(lap_f.*C)));
        u_aug = rho*u_aug;
        N_I =  norm(M_hr_new(:,:,i)-M_hr_old(:,:,i))/norm(M_hr_old(:,:,i));
        %         F_final(:,:,i) = M(:,:,i)+ M_rate(:,:,i).*(M_hr(:,:,i)-M(:,:,i));
    end
    %           F_final(:,:,i) = M(:,:,i)+ g*M_rate(:,:,i).* (P-I);
    %     imshow(M_hr_new(:,:,i));
end
end
