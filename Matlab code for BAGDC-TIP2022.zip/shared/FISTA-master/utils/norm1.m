function res = norm1(X)
	res = full(sum(abs(X(:))));
end
