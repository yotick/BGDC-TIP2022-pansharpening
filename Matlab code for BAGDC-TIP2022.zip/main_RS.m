clc; clear all; close all;

% addpath(genpath('E:\remote sense image fusion\shared'))

% global  ratio file_path_rgb256;
% global count time curr_d gt256;
% global sensor sate num mu L Qblocks_size flag_cut_bounds dim_cut thvalues;
% global eps;
global  sensor ratio  sate;

curr_d = pwd;
sate = 'ik';   % ik,pl��wv3-8
sensor = 'IKONOS';
ratio = 4;
method = 'BAGDC';


%% read images and preprocess
num = 1;
% ############# this part should be changed for reading images ############
% [rgb256, gt256, img_mul, P ] = read_image_sate_RS(num);   % need to change

%% tic start
tic;
F_final = BADGC(img_mul, M, P);

%% end and get RGB
toc
time(num) = toc;

for i = 1:3
    F_rgb(:,:,i) =  F_final(:,:,i);
    
end
%% ##### save images, should be changed #######
% save_sate_RS(F_final, M, F_rgb, num);   
% end

%% show image

% Eval = Evaluation4(ORM,pan256,uint8(F_final*255))
% [Q_avg_Segm, SAM_Segm, ERGAS_Segm, SCC_GT_Segm, Q_Segm] = indexes_evaluation(...
%     uint8(F_final*255),ORM,ratio,L,Qblocks_size,flag_cut_bounds,dim_cut,thvalues);
% Eval2 = [Q_avg_Segm, SAM_Segm, ERGAS_Segm, SCC_GT_Segm, Q_Segm]

figure,
imshow(F_rgb);
title('proposed');
figure,imshow(rgb256);
title('GT');
% figure, imshow(rgb256)
cd(curr_d);
%% write result
% T = quality_eval_sate_RS();
% cd(curr_d);
% writetable(T,strcat('final_result/quality_',method,'_4C_',sate,'_RS_last.csv'),'WriteRowNames',true);

